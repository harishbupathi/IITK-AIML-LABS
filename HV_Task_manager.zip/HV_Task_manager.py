# ============================================================
# STEP 0: IMPORT REQUIRED MODULES
# ============================================================
import csv       # For saving and reading data from files
import hashlib   # For password hashing (security)
import os        # For checking if files exist
import sys       # For system exit
import getpass   # For secure password input (hidden typing)
import logging   # For logging events (like login attempts)

# ── Constants ─────────────────────────────────────────────────────────────────
USERS_FILE        = "users.csv"
USERS_HEADERS     = ["username", "password_hash"]
TASKS_HEADERS     = ["task_id", "description", "status"]
STATUS_PENDING    = "Pending"
STATUS_COMPLETED  = "Completed"

# ============================================================
# STEP 1: HELPER FUNCTIONS (Password Hashing + User File Handling)
# ============================================================

def hash_password(password):
    """Return a hashed version of the password using SHA256."""
    return hashlib.sha256(password.encode()).hexdigest()

def load_users():
    """Load user credentials from users.csv into a dictionary."""
    users = {}
    if os.path.exists("users.csv"):
        with open("users.csv", "r", newline="") as file:
            reader = csv.reader(file)
            for row in reader:
                if len(row) == 2:
                    username, password_hash = row
                    users[username] = password_hash
    return users

def save_user(username, password_hash):
    """Save a new user to users.csv."""
    with open("users.csv", "a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([username, password_hash])

# ============================================================
# STEP 2: USER AUTHENTICATION (Register + Login)
# ============================================================

def register():
    """Register a new user with unique username and hashed password."""
    users = load_users()
    username = input("Enter a new username: ")
    if username in users:
        print("Username already exists. Try another.")
        return None
    password = input("Enter a password: ")
    password_hash = hash_password(password)
    save_user(username, password_hash)
    print("Registration successful!")
    return username

def login():
    """Login an existing user by checking stored credentials."""
    users = load_users()
    username = input("Enter username: ")
    password = input("Enter password: ")
    password_hash = hash_password(password)
    if username in users and users[username] == password_hash:
        print("Login successful!")
        return username
    else:
        print("Invalid credentials.")
        return None

# ============================================================
# STEP 3: TASK MANAGEMENT FUNCTIONS (Add, View, Complete, Delete)
# ============================================================

def get_task_file(username):
    """Return the filename for the user's task list."""
    return f"{username}_tasks.csv"

def add_task(username):
    """Add a new task with unique ID and status Pending."""
    task_file = get_task_file(username)
    task_id = 1
    tasks = []
    if os.path.exists(task_file):
        with open(task_file, "r", newline="") as file:
            reader = list(csv.reader(file))
            tasks = reader
            if tasks:
                task_id = int(tasks[-1][0]) + 1
    description = input("Enter task description: ")
    status = "Pending"
    with open(task_file, "a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([task_id, description, status])
    print("Task added successfully!")

def view_tasks(username):
    """View all tasks for the logged-in user."""
    task_file = get_task_file(username)
    if not os.path.exists(task_file):
        print("No tasks found.")
        return
    with open(task_file, "r", newline="") as file:
        reader = csv.reader(file)
        print("\nYour Tasks:")
        for row in reader:
            if len(row) == 3:
                task_id, description, status = row
                print(f"ID: {task_id} | {description} | Status: {status}")

def mark_task_completed(username):
    """Mark a task as Completed by its ID."""
    task_file = get_task_file(username)
    if not os.path.exists(task_file):
        print("No tasks found.")
        return
    tasks = []
    with open(task_file, "r", newline="") as file:
        reader = csv.reader(file)
        tasks = list(reader)
    task_id = input("Enter task ID to mark as completed: ")
    updated = False
    for row in tasks:
        if row[0] == task_id:
            row[2] = "Completed"
            updated = True
    if updated:
        with open(task_file, "w", newline="") as file:
            writer = csv.writer(file)
            writer.writerows(tasks)
        print("Task marked as completed!")
    else:
        print("Task ID not found.")

def delete_task(username):
    """Delete a task by its ID."""
    task_file = get_task_file(username)
    if not os.path.exists(task_file):
        print("No tasks found.")
        return
    tasks = []
    with open(task_file, "r", newline="") as file:
        reader = csv.reader(file)
        tasks = list(reader)
    task_id = input("Enter task ID to delete: ")
    new_tasks = [row for row in tasks if row[0] != task_id]
    if len(new_tasks) != len(tasks):
        with open(task_file, "w", newline="") as file:
            writer = csv.writer(file)
            writer.writerows(new_tasks)
        print("Task deleted successfully!")
    else:
        print("Task ID not found.")

# ============================================================
# STEP 4: TASK MANAGER MENU (Interactive Options)
# ============================================================

def task_manager(username):
    """Interactive menu for managing tasks."""
    while True:
        print("\n--- Task Manager ---")
        print("1. Add Task")
        print("2. View Tasks")
        print("3. Mark Task as Completed")
        print("4. Delete Task")
        print("5. Logout")
        choice = input("Enter your choice: ")
        if choice == "1":
            add_task(username)
        elif choice == "2":
            view_tasks(username)
        elif choice == "3":
            mark_task_completed(username)
        elif choice == "4":
            delete_task(username)
        elif choice == "5":
            print("Logging out...")
            break
        else:
            print("Invalid choice. Try again.")

# ============================================================
# STEP 5: MAIN PROGRAM LOOP (Register/Login/Exit)
# ============================================================

def main():
    """Main program loop for user authentication and task manager."""
    while True:
        print("\n--- Welcome to Task Manager ---")
        print("1. Register")
        print("2. Login")
        print("3. Exit")
        choice = input("Enter your choice: ")
        if choice == "1":
            user = register()
            if user:
                task_manager(user)
        elif choice == "2":
            user = login()
            if user:
                task_manager(user)
        elif choice == "3":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")

# ============================================================
# STEP 6: RUN THE PROGRAM
# ============================================================

if __name__ == "__main__":
    main()

